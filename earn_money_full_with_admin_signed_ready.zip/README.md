# Earn Money — Flutter + Firebase + Admin Panel (Ready)

This package contains:
- **Flutter Android app** (rewarded video → points, withdraw requests)
- **Admin Panel (web_admin/)** to change **taskReward**, **min/max withdraw**, **withdraw ON/OFF**, and **mark paid**
- **Android signing templates** (`android/keystore/` + `gradle.properties.template`)
- **Codemagic CI config** (`codemagic.yaml`)

## 1) Firebase setup (mobile)
1. In Firebase Console, create project `earn-money-c536d` (already exists).
2. Download **google-services.json** for Android package **com.armangamesstudio.EarnMoney** and place it at:
   `android/app/google-services.json` (replace the placeholder file).

## 2) Firebase setup (admin panel)
- Open `web_admin/firebase-config.js` → already prefilled for your project.
- Optional: change admin password in `web_admin/admin-config.js`.

## 3) Run locally (development)
```bash
flutter pub get
flutter run
```

## 4) Build a release APK (locally)
First configure signing:
- Copy `android/keystore/gradle.properties.template` to **android/gradle.properties**
- Either generate a keystore (see below) and fill these values, or use env vars on CI.

Then build:
```bash
flutter build apk --release
```

The APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

## 5) Generate a release keystore (one-time)
```bash
keytool -genkey -v -keystore my-release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload
# It will ask for passwords and org info. Remember them!
```
Move the file to: `android/keystore/my-release-key.jks`

Edit `android/gradle.properties` (created from template) to set:
```
MY_KEYSTORE_FILE=keystore/my-release-key.jks
MY_KEYSTORE_PASSWORD=your_store_password
MY_KEY_ALIAS=upload
MY_KEY_PASSWORD=your_key_password
```

## 6) Android Studio signing (GUI)
- Open **Android** folder in Android Studio → *Build* > *Generate Signed Bundle / APK...*
- Select **APK** → Next → Create New or Choose existing keystore → fill passwords → Next → **release** → Finish.

## 7) Codemagic setup (CI)
- Upload this zip as a new app on Codemagic.
- In **Environment variables**, set:
  - `KEYSTORE` → upload `android/keystore/my-release-key.jks` as **Secure file**
  - `KEYSTORE_PASSWORD`, `KEY_PASSWORD`, `KEY_ALIAS`
- Add your `google-services.json` as a secure file and map it to `android/app/google-services.json`
- `codemagic.yaml` already contains a release workflow reading those values.

## 8) Admin Panel (how to open)
- Just open `web_admin/index.html` in a browser (or host anywhere static).
- Enter the admin password (default `admin123`), then edit settings or mark withdraws as paid.

## Notes
- Replace AdMob test IDs with your real IDs before publishing.
- Secure your Firestore rules before going to production.
