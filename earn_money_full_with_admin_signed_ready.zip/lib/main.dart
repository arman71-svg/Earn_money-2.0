// Flutter app with admin-controlled settings and withdraw flow
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:intl/intl.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  MobileAds.instance.initialize();
  await FirebaseAuth.instance.signInAnonymously();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Earn Money',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final user = FirebaseAuth.instance.currentUser;
  int points = 0;
  late final CollectionReference<Map<String, dynamic>> users =
      FirebaseFirestore.instance.collection('users');

  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? userSub;
  StreamSubscription<DocumentSnapshot<Map<String, dynamic>>>? settingsSub;

  // settings
  int taskReward = 10;
  int minWithdraw = 50;
  int maxWithdraw = 1000;
  bool withdrawEnabled = true;

  RewardedAd? rewardedAd;
  bool adReady = false;

  @override
  void initState() {
    super.initState();
    if (user == null) return;
    userSub = users.doc(user!.uid).snapshots().listen((snap) {
      if (snap.exists) {
        setState(() => points = (snap.data()?['points'] ?? 0) as int);
      } else {
        users.doc(user!.uid).set({'points': 0});
      }
    });
    settingsSub = FirebaseFirestore.instance
        .collection('settings')
        .doc('global')
        .snapshots()
        .listen((snap) {
      if (snap.exists) {
        final d = snap.data()!;
        setState(() {
          taskReward = (d['taskReward'] ?? 10) as int;
          minWithdraw = (d['minWithdraw'] ?? 50) as int;
          maxWithdraw = (d['maxWithdraw'] ?? 1000) as int;
          withdrawEnabled = (d['withdrawEnabled'] ?? true) as bool;
        });
      }
    });
    _loadRewarded();
  }

  void _loadRewarded() {
    RewardedAd.load(
      adUnitId: 'ca-app-pub-3940256099942544/5224354917', // test unit
      request: const AdRequest(),
      rewardedAdLoadCallback: RewardedAdLoadCallback(
        onAdLoaded: (ad) {
          rewardedAd = ad;
          adReady = true;
          rewardedAd!.fullScreenContentCallback = FullScreenContentCallback(
            onAdDismissedFullScreenContent: (ad) { ad.dispose(); _loadRewarded(); },
            onAdFailedToShowFullScreenContent: (ad, err) { ad.dispose(); _loadRewarded(); },
          );
          setState((){});
        },
        onAdFailedToLoad: (err) { adReady = false; setState((){}); },
      ),
    );
  }

  void _watchAd() {
    if (!adReady || rewardedAd == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Ad not ready yet')));
      return;
    }
    rewardedAd!.show(onUserEarnedReward: (ad, reward) async {
      await users.doc(user!.uid).update({'points': FieldValue.increment(taskReward)});
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Earned $taskReward points')));
    });
    rewardedAd = null; adReady = false;
  }

  @override
  void dispose() {
    userSub?.cancel();
    settingsSub?.cancel();
    rewardedAd?.dispose();
    super.dispose();
  }

  String fmt(int v) => NumberFormat.decimalPattern().format(v);

  void _openWithdrawDialog() {
    if (!withdrawEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Withdrawals are disabled now')));
      return;
    }
    final formKey = GlobalKey<FormState>();
    String method='bKash'; String mobile=''; int amount=minWithdraw;
    showDialog(context: context, builder: (c){
      return AlertDialog(
        title: const Text('Withdraw Request'),
        content: Form(
          key: formKey,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField(value: method, items: const [
              DropdownMenuItem(value:'bKash', child: Text('bKash')),
              DropdownMenuItem(value:'Nagad', child: Text('Nagad')),
            ], onChanged: (v){ method = v ?? 'bKash'; }),
            TextFormField(decoration: const InputDecoration(labelText:'Mobile (11 digits)'), keyboardType: TextInputType.phone,
              onChanged: (v)=> mobile=v.trim(),
              validator: (v){ if ((v??'').trim().length<11) return 'Enter valid mobile'; return null; }),
            TextFormField(initialValue: amount.toString(), decoration: const InputDecoration(labelText:'Amount (points)'), keyboardType: TextInputType.number,
              onChanged: (v)=> amount=int.tryParse(v)??0,
              validator: (v){ final val=int.tryParse(v??'')??0;
                if (val<minWithdraw) return 'Minimum is $minWithdraw';
                if (val>maxWithdraw) return 'Maximum is $maxWithdraw';
                if (val>points) return 'Not enough points';
                return null; }),
          ]),
        ),
        actions: [
          TextButton(onPressed: ()=>Navigator.of(c).pop(), child: const Text('Cancel')),
          FilledButton(onPressed: () async {
            if (!formKey.currentState!.validate()) return;
            final userRef = users.doc(user!.uid);
            final withdraws = FirebaseFirestore.instance.collection('withdraw_requests');
            try {
              await FirebaseFirestore.instance.runTransaction((tx) async {
                final snap = await tx.get(userRef);
                final current = (snap.data()?['points'] ?? 0) as int;
                if (current < amount) throw Exception('Not enough points');
                tx.update(userRef, {'points': current - amount});
                tx.set(withdraws.doc(), {{
                  'userId': user!.uid, 'method': method, 'mobile': mobile,
                  'amountPoints': amount, 'status':'pending',
                  'createdAt': FieldValue.serverTimestamp(),
                }});
              });
              if (context.mounted) Navigator.of(c).pop();
              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Withdraw request created')));
            } catch (e) {
              if (context.mounted) Navigator.of(c).pop();
              ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Failed: $e')));
            }
          }, child: const Text('Submit')),
        ],
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Earn Money'), actions: [
        Padding(padding: const EdgeInsets.only(right:16), child: Center(child: Text('Balance: ${fmt(points)}')))
      ]),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Card(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), elevation: 3,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Watch Rewarded Video', style: TextStyle(fontSize:18, fontWeight: FontWeight.w600)),
                  const SizedBox(height:6),
                  Text('Earn ${fmt(taskReward)} points per video'),
                  const SizedBox(height:6),
                  Text('Withdraw: min ${fmt(minWithdraw)} • max ${fmt(maxWithdraw)}'),
                ]),
                FilledButton.icon(onPressed: adReady? _watchAd : null, icon: const Icon(Icons.play_circle), label: Text(adReady? 'Watch' : 'Loading')),
              ]),
            ),
          ),
          const SizedBox(height:12),
          Row(children: [
            Expanded(child: FilledButton.tonalIcon(onPressed: points>=minWithdraw? _openWithdrawDialog : null, icon: const Icon(Icons.account_balance_wallet), label: const Text('Withdraw'))),
            const SizedBox(width:12),
            OutlinedButton.icon(onPressed: (){
              Navigator.of(context).push(MaterialPageRoute(builder: (_)=> const HistoryPage()));
            }, icon: const Icon(Icons.history), label: const Text('History'))
          ]),
          const SizedBox(height:12),
          Expanded(child: const HistoryListEmbedded()),
        ]),
      ),
    );
  }
}

class HistoryListEmbedded extends StatelessWidget {
  const HistoryListEmbedded({super.key});
  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return StreamBuilder(
      stream: FirebaseFirestore.instance.collection('withdraw_requests')
        .where('userId', isEqualTo: user.uid).orderBy('createdAt', descending: true).limit(20).snapshots(),
      builder: (context, snap){
        if (!snap.hasData) return const SizedBox();
        final docs = (snap.data as QuerySnapshot<Map<String,dynamic>>).docs;
        if (docs.isEmpty) return const Center(child: Text('No withdraw requests yet'));
        return ListView.builder(
          itemCount: docs.length,
          itemBuilder: (_, i){
            final d = docs[i].data();
            final created = (d['createdAt'] as Timestamp?)?.toDate();
            return Card(child: ListTile(
              title: Text('${d['amountPoints']} pts — ${d['method']}'),
              subtitle: Text('Status: ${d['status']} • ${created!=null?created.toLocal().toString().split('.')[0]:''}'),
            ));
          });
      },
    );
  }
}

class HistoryPage extends StatelessWidget {
  const HistoryPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(appBar: AppBar(title: const Text('Withdraw History')), body: const Padding(
      padding: EdgeInsets.all(8.0), child: HistoryListEmbedded()));
  }
}
