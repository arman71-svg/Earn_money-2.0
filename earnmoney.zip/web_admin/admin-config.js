const ADMIN_PASSWORD = 'admin123';
